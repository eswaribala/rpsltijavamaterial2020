import { Component } from '@angular/core';
//meta data
@Component({
  selector: 'ecommerce-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  private logoPath:string;
  private title:string;
  private banner:string;
  constructor() {
    this.logoPath="./assets/images/logo.png";
    this.title="LTI Store Front";
    this.banner="./assets/images/gallery4.jpg"
  }

}
