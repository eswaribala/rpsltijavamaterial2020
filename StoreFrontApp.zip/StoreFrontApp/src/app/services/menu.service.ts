import { Injectable } from '@angular/core';
import {menuData} from "../Data/menuData";

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor() { }

  getMenuData():any
    {
      return menuData;
    }
}
