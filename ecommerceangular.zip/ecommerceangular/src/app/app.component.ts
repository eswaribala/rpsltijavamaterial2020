import {Component, OnInit} from '@angular/core';
import {CategoryService} from "./services/category.service";
//meta data
@Component({
  selector: 'ecommerce-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  private logoPath:string;
  private title:string;
  private banner:string;
  private categories:any
  user: any;
  searchString: any;
  category: any;
  constructor(private categoryService:CategoryService ) {
    this.logoPath="./assets/images/logo.png";
    this.title="LTI Store Front";
    this.banner="./assets/images/gallery4.jpg"
  }

  ngOnInit(): void {
    this.categoryService.getAllCategories().subscribe(response=>{
      console.log(response);
      this.categories=response;
    })
  }

  checkUser() {

  }
}
