import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {MenuComponent} from "./menu/menu.component";
import {CategoryAddComponent} from "./category/category-add/category-add.component";
import {CategoryComponent} from "./category/category.component";
import {CategoryEditComponent} from "./category/category-edit/category-edit.component";
import {CategoryDeleteComponent} from "./category/category-delete/category-delete.component";
import {CategoryViewComponent} from "./category/category-view/category-view.component";
import {CategoryViewAllComponent} from "./category/category-view-all/category-view-all.component";
import {ProductComponent} from "./product/product.component";
import {ProductAddComponent} from "./product/product-add/product-add.component";
import {ProductEditComponent} from "./product/product-edit/product-edit.component";
import {ProductDeleteComponent} from "./product/product-delete/product-delete.component";
import {ProductViewComponent} from "./product/product-view/product-view.component";
import {ProductViewAllComponent} from "./product/product-view-all/product-view-all.component";
import {AccountComponent} from "./account/account.component";
import {ShippingComponent} from "./shipping/shipping.component";


const routes: Routes = [

  {
    path:'Category',
    component:CategoryComponent,
    children:[{
      path:'CategoryAdd',
      component:CategoryAddComponent
    },
      {
        path:'CategoryEdit',
        component:CategoryEditComponent
      } ,
      {
        path:'CategoryDelete',
        component:CategoryDeleteComponent
      },
      {
        path:'CategoryView',
        component:CategoryViewComponent
      },
      {
        path:'CategoryViewAll',
        component:CategoryViewAllComponent
      }

    ]
  },
    {
      path:'Product',
      component:ProductComponent,
      children:[{
        path:'ProductAdd',
        component:ProductAddComponent
      },
        {
          path:'ProductEdit',
          component:ProductEditComponent
        } ,
        {
          path:'ProductDelete',
          component:ProductDeleteComponent
        },
        {
          path:'ProductView',
          component:ProductViewComponent
        },
        {
          path:'ProductViewAll',
          component:ProductViewAllComponent
        }

      ]
    },

    {
      path:"Account",
      component: AccountComponent
    },
    {
      path: 'Shipping',
      component: ShippingComponent
    }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
