import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoryViewAllComponent } from './category-view-all.component';

describe('CategoryViewAllComponent', () => {
  let component: CategoryViewAllComponent;
  let fixture: ComponentFixture<CategoryViewAllComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategoryViewAllComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CategoryViewAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
