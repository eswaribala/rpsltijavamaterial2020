import React from 'react'
import Logo from '../assets/images/logo.png'
import './logo.css'
//stateless component
const LtiLogo=()=>(
     <img src={Logo} className="logo" />
);
export default LtiLogo;
