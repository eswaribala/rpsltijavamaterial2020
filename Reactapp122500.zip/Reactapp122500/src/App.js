import './App.css';
import {Component} from "react";
import LtiLogo from './Logo/logo'

//stateful component
export class App extends Component{

    constructor(props) {
        super(props);
        console.log("Inside Constructor");
    }

    componentWillMount() {
        //super.componentWillMount();
        console.log("Enters Component will mount");
    }

    componentDidMount() {
        //super.componentDidMount();
        console.log("Enters Component did mount");
    }

    render() {
        return (
            <div>
                <figure>
                    <LtiLogo/>
                </figure>
            </div>
        )
    }
}

/*
function App() {
  return (
    <div className="App">
      <header >

      </header>
    </div>
  );
}

export default App;

 */
