import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MenubarModule} from 'primeng/menubar';
import { MenuComponent } from './menu/menu.component';
import { CategoryComponent } from './category/category.component';

import { CategoryAddComponent } from './category/category-add/category-add.component';
import { CategoryEditComponent } from './category/category-edit/category-edit.component';
import { CategoryDeleteComponent } from './category/category-delete/category-delete.component';
import { CategoryViewComponent } from './category/category-view/category-view.component';
import { CategoryViewAllComponent } from './category/category-view-all/category-view-all.component';
import { ProductComponent } from './product/product.component';
import { ProductAddComponent } from './product/product-add/product-add.component';
import { ProductEditComponent } from './product/product-edit/product-edit.component';
import { ProductDeleteComponent } from './product/product-delete/product-delete.component';
import { ProductViewComponent } from './product/product-view/product-view.component';
import { ProductViewAllComponent } from './product/product-view-all/product-view-all.component';
import { AccountComponent } from './account/account.component';
import { ShippingComponent } from './shipping/shipping.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatFormFieldModule} from "@angular/material/form-field";
import {MatIconModule} from "@angular/material/icon";
import {MatInputModule} from "@angular/material/input";
import {MatButtonModule} from "@angular/material/button";
import {HttpClientModule} from "@angular/common/http";
//import {MenuItem} from 'primeng/api';
//metadata
@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    CategoryComponent,
    CategoryAddComponent,
    CategoryEditComponent,
    CategoryDeleteComponent,
    CategoryViewComponent,
    CategoryViewAllComponent,
    ProductComponent,
    ProductAddComponent,
    ProductEditComponent,
    ProductDeleteComponent,
    ProductViewComponent,
    ProductViewAllComponent,
    AccountComponent,
    ShippingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MenubarModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatButtonModule,
    HttpClientModule


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
