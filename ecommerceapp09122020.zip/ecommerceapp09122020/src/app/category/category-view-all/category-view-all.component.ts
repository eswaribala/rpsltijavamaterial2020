import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-view-all',
  templateUrl: './category-view-all.component.html',
  styleUrls: ['./category-view-all.component.css']
})
export class CategoryViewAllComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
