import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-view-all',
  templateUrl: './product-view-all.component.html',
  styleUrls: ['./product-view-all.component.css']
})
export class ProductViewAllComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
